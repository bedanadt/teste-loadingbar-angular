import StepInterface from "src/app/loading/Interfaces/Step";
import StepStatus from "src/app/loading/Enums/StepStatus";

class Step implements StepInterface {
  name: string;
  status: number;

  constructor(name:string) {
    this.name = name;
    this.status = StepStatus.NOT_PROCESSED;
  }
}

export default Step;