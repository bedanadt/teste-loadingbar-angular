enum StepStatus {
  NOT_PROCESSED = 1,
  PROCESSING = 2,
  PROCESSED = 3
};

export default StepStatus;