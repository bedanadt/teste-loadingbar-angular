interface Step {
  name: string;
  status: number;
}

export default Step;
