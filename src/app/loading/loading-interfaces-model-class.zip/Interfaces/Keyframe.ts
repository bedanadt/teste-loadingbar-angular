interface Keyframe {
  time: number;
  step?: string;
  title?: string;
  subtitle?: string;
}

export default Keyframe;