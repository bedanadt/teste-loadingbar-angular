import Step from "src/app/loading/Interfaces/Step";

interface InternalKeyframe {
  title: String
  subtitle: String
  step: Step
}

interface Timeframes {
  [index: number]: InternalKeyframe
}

export { InternalKeyframe, Timeframes };